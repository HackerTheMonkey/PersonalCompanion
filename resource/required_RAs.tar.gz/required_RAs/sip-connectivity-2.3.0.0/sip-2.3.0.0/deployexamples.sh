#!/bin/sh

../../client/bin/rhino-import . deployexamples

