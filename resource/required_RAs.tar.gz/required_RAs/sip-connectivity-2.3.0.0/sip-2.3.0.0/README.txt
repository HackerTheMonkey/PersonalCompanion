SIP Connectivity Pack

Open the file "docs/index.html" in your browser, to find release notes, and
information about the SIP resource adaptor and example applications.




