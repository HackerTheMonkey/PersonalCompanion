#!/bin/sh

../../client/bin/rhino-import . undeployexamples

